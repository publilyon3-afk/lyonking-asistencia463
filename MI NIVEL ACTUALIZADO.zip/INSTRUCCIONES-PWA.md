# LyonKing PWA — Guía de instalación en Firebase Hosting

## Estructura de archivos que necesitás subir

```
public/
├── index.html          ← lyonking-v5-mobile.html (renombrado)
├── manifest.json       ← incluido
├── sw.js               ← service worker incluido
├── lyonking-bg.png     ← tu imagen de fondo (si la tenés)
└── icons/
    ├── icon-192.png    ← generalo con generar-iconos.html
    └── icon-512.png    ← ídem
```

---

## Pasos para subir a Firebase Hosting

### 1. Instalar Firebase CLI (una sola vez)
```bash
npm install -g firebase-tools
```

### 2. Iniciar sesión
```bash
firebase login
```

### 3. Inicializar el proyecto (en la carpeta raíz)
```bash
firebase init hosting
```
Cuando te pregunte:
- **Public directory:** `public`
- **Single-page app:** `Yes`
- **GitHub deploys:** No

### 4. Copiar archivos a la carpeta `public/`
- Renombrá `lyonking-v5-mobile.html` → `public/index.html`
- Copiá `manifest.json` → `public/manifest.json`
- Copiá `sw.js` → `public/sw.js`
- Creá carpeta `public/icons/` y poné los dos íconos ahí

### 5. Reemplazar firebase.json con el incluido

### 6. Subir
```bash
firebase deploy
```

---

## Cómo instalan la app los usuarios

### Android (Chrome)
1. Entrar al sitio en Chrome
2. Aparece automáticamente un banner "Agregar a pantalla de inicio"
3. O: menú ⋮ → "Instalar app" / "Agregar a pantalla de inicio"

### iPhone (Safari) — importante: solo funciona en Safari
1. Abrir el sitio en **Safari** (no Chrome en iOS)
2. Tocar el botón compartir ↑
3. "Agregar a pantalla de inicio"
4. Listo — aparece como app nativa

---

## Verificar que la PWA funciona

En Chrome desktop:
1. Abrir DevTools → pestaña **Application**
2. En **Manifest** vas a ver los datos de tu app
3. En **Service Workers** vas a ver el SW activo
4. En **Lighthouse** → Generate report → revisá la puntuación PWA

---

## Notas importantes

- **El service worker solo funciona en HTTPS** — Firebase Hosting lo incluye automáticamente ✓
- **Los íconos son obligatorios** para que Chrome muestre el banner de instalación
- Si cambiás algo en el HTML, el SW actualiza el cache automáticamente en la próxima visita
- El archivo `sw.js` tiene `Cache-Control: no-cache` para que siempre se descargue fresco

---

## Generar los íconos

Abrí `generar-iconos.html` en el navegador y descargá los dos archivos PNG.
Subílos a `public/icons/`.
