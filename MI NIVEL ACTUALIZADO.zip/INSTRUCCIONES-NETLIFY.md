# LyonKing PWA — Guía para Netlify

## Archivos que necesitás tener en tu repo

```
tu-repo/
├── index.html          ← lyonking-v5-mobile.html renombrado
├── manifest.json
├── sw.js
├── netlify.toml        ← configuración de headers (incluido)
├── lyonking-bg.png     ← tu imagen de fondo (si la usás)
└── icons/
    ├── icon-192.png    ← generalo con generar-iconos.html
    └── icon-512.png
```

---

## Opción A — Subir arrastrando archivos (sin Git, lo más simple)

1. Entrá a **app.netlify.com**
2. En el dashboard, arrastrá toda la carpeta al área "Deploy manually"
3. Listo — Netlify te da una URL tipo `lyonking.netlify.app`

---

## Opción B — Conectar con GitHub (recomendado, se actualiza solo)

1. Subí todos los archivos a un repo de GitHub
2. En Netlify: **Add new site → Import from Git**
3. Seleccioná tu repo
4. En **Build settings**:
   - Build command: (dejar vacío)
   - Publish directory: `.` (punto — la raíz del repo)
5. **Deploy site**

Cada vez que hagas push a GitHub, Netlify actualiza la app automáticamente.

---

## Dominio personalizado (opcional)

En Netlify: **Site settings → Domain management → Add custom domain**
Podés usar algo como `asistencia.tuempresa.com` en vez de la URL de Netlify.

---

## Cómo instalan la app los usuarios

### Android (Chrome)
- Chrome muestra automáticamente un banner "Instalar app"
- O: menú ⋮ → "Instalar app" / "Agregar a pantalla de inicio"

### iPhone (Safari) ⚠️ Solo funciona en Safari, no Chrome
1. Abrir el sitio en **Safari**
2. Botón compartir ↑
3. "Agregar a pantalla de inicio"
4. Aparece como app nativa en el home

---

## Verificar que la PWA está activa

En Chrome desktop:
- DevTools → **Application → Manifest** (debe mostrar nombre, íconos, colores)
- DevTools → **Application → Service Workers** (debe aparecer como "activated")
- Herramienta **Lighthouse** → Generate report → sección PWA

---

## Generar los íconos

Abrí `generar-iconos.html` en el navegador → descargá los dos PNG → subílos a la carpeta `icons/`.

---

## Notas

- Netlify incluye HTTPS automático — el service worker lo requiere ✓
- El `netlify.toml` es clave: sin los headers correctos el SW no se registra bien
- Si ya tenías el sitio en Netlify sin PWA, solo agregá los archivos nuevos y hacé redeploy
