// LyonKing PWA Service Worker
const CACHE_NAME = 'lyonking-v1';

// Archivos estáticos a cachear (ajustá si cambiás el nombre del HTML)
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json'
];

// ── INSTALL: cachear archivos estáticos ──────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

// ── ACTIVATE: limpiar caches viejas ─────────────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// ── FETCH: Network first, cache fallback ─────────────────────
// Firebase/Firestore calls siempre van a la red (no se cachean)
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // No cachear Firebase, Firestore, Auth, CDN externos
  const skipCache = [
    'firebaseio.com',
    'firestore.googleapis.com',
    'googleapis.com',
    'gstatic.com',
    'cdn.jsdelivr.net',
    'identitytoolkit.googleapis.com'
  ].some(domain => url.hostname.includes(domain));

  if (skipCache) {
    // Siempre ir a la red para Firebase
    return;
  }

  // Para archivos estáticos propios: cache first, network fallback
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        // Solo cachear respuestas válidas
        if (!response || response.status !== 200 || response.type === 'opaque') {
          return response;
        }
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() => {
        // Si no hay red y no hay cache, mostrar offline page básica
        return new Response(
          '<html><body style="background:#0f0f0f;color:#f5c842;font-family:system-ui;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center"><div><div style="font-size:32px;font-weight:900;letter-spacing:4px">LYONKING</div><p style="color:#555;margin-top:1rem">Sin conexión a internet.<br>Reconectate para usar la app.</p></div></body></html>',
          { headers: { 'Content-Type': 'text/html' } }
        );
      });
    })
  );
});
